# Model and Output Provenance

This directory documents recoverable model versions, evaluated output
identities, checkpoint files, inference configurations, and local code
modifications for the benchmark.

## AlphaFold 3

af3_evaluated_outputs.csv identifies the exact evaluated coordinate
file for each of the 124 shared benchmark targets, including its
SHA-256 checksum.

The evaluation file was fixed by the archived benchmark manifest.
This is the deterministic selection procedure for reproducing the
reported benchmark, not proof of a prospectively specified historical
selection policy.

For target 8YHN_A, two archived output directories exist.
af3_8YHN_candidates.csv identifies the evaluated and alternative CIF
files separately.

The historical rationale for choosing the earlier output directory
could not be independently established and remains UNVERIFIED.

Paths are relative to the original structure_prediction directory.
The supporting portable structure-evaluation archive provides the
evaluated coordinate files for independent metric reproduction.

## MultiFlow

Upstream Git commit:
6278899970523bad29953047e7a42b32a41dc813

The archived benchmark Hydra run is:
2026-11-09/07-50-35

Its configuration records:
- Seed: 123
- Sampling timesteps: 500
- Lengths: 100, 200, 300, 400, 500
- Samples per length: 100
- generation_only: true
- also_fold_pmpnn_seq: false
- Checkpoint: weights/last.ckpt

The local patch contains generation-only support, folding and
subprocess changes, and optional DeepSpeed integration.

The generation-only setting is directly supported by the archived
benchmark configuration. The supplied patch represents the recovered
current local modifications; its complete identity with the working
tree at the historical benchmark run is not independently verified.

## Checkpoints

model_checkpoint_provenance.csv lists the available MultiFlow,
ProteinGenerator, and Protpardelle-1c checkpoint identifiers and
SHA-256 hashes.

A verified hash establishes the identity of the existing checkpoint
file, but does not by itself establish which weights were loaded in
a historical inference run.

Checkpoint weights are not included in this small provenance archive.

## Evidence categories

verified: directly supported by archived files or their checksums.

supported_by_hydra_config: identified in an archived run configuration.

unverified: the available records do not establish the historical
fact with sufficient confidence.
