#!/usr/bin/env python3
"""Recompute C-alpha RMSD, per-residue lDDT-Ca and matched-length TM-score.

Run within an existing structure_prediction tree. This script deliberately keeps
both the historical per-model correspondence and a common FASTA-position mode
for auditing; it never overwrites published metrics.
"""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from Bio.PDB import PDBParser, MMCIFParser
from Bio.SeqUtils import seq1
from Bio.Align import PairwiseAligner
from scipy.spatial.distance import pdist, squareform
from tmtools import tm_align

MODELS = ('AlphaFold3','Boltz-2','ESMFold','Chai-1')


def read_structure(path, label):
    if not path.is_file():
        raise FileNotFoundError(str(path))
    parser = MMCIFParser(QUIET=True) if path.suffix.lower() in ('.cif','.mmcif') else PDBParser(QUIET=True)
    return parser.get_structure(label, str(path))[0]


def ca_residues(model):
    return [r for r in model.get_residues() if r.id[0] == ' ' and 'CA' in r]


def as_aa(residue):
    return seq1(residue.resname, custom_map={'UNK':'X'})


def sequence_pairs(native, predicted):
    """Reproduce historical AF3/Chai alignment and discard AA mismatches."""
    s1=''.join(as_aa(r) for r in native)
    s2=''.join(as_aa(r) for r in predicted)
    aligner=PairwiseAligner(mode='global')
    aligner.match_score=2
    aligner.mismatch_score=-1
    aligner.open_gap_score=-8
    aligner.extend_gap_score=-0.5
    aln=aligner.align(s1,s2)[0]
    pairs=[]
    for (i0,i1),(j0,j1) in zip(*aln.aligned):
        if i1-i0 != j1-j0:
            raise ValueError('Unequal alignment block length')
        for i,j in zip(range(i0,i1),range(j0,j1)):
            if s1[i]==s2[j]:
                pairs.append((native[i],predicted[j], j+1))
    return pairs


def mapping_pairs(native_model, predicted, mapping, check_identity=True):
    """Historical ESMFold/Boltz residue correspondence by FASTA position.

    Missing native residue identifiers are an explicit error; absent predicted
    positions or unavailable C-alpha atoms are omitted, as in original code.
    """
    by_pos={i+1:r for i,r in enumerate(predicted)}
    pairs=[]
    for row in mapping.sort_values('fasta_position').itertuples(index=False):
        pos=int(row.fasta_position)
        if pos not in by_pos:
            continue
        chain=native_model[str(row.experimental_chain)]
        ins=str(row.experimental_insertion_code).strip() or ' '
        residue=chain[(' ',int(row.experimental_residue_number),ins)]
        pred=by_pos[pos]
        if 'CA' not in residue:
            continue
        if check_identity and as_aa(residue) != as_aa(pred):
            raise ValueError(f'AA mismatch at position {pos}: {as_aa(residue)} vs {as_aa(pred)}')
        pairs.append((residue,pred,pos))
    return pairs


def kabsch_rmsd(native, predicted):
    a=np.asarray(native,dtype=np.float64)
    b=np.asarray(predicted,dtype=np.float64)
    if a.shape != b.shape or len(a)<3:
        raise ValueError('At least 3 paired coordinates needed for RMSD')
    ac=a-a.mean(axis=0)
    bc=b-b.mean(axis=0)
    u,_,vt=np.linalg.svd(bc.T @ ac)
    correction=np.eye(3)
    correction[-1,-1]=np.sign(np.linalg.det(u @ vt))
    aligned=bc @ (u @ correction @ vt)
    return float(np.sqrt(np.mean(np.sum((aligned-ac)**2,axis=1))))


def lddt_per_residue(native, predicted, positions):
    native=np.asarray(native,dtype=np.float64)
    predicted=np.asarray(predicted,dtype=np.float64)
    pos=np.asarray(positions,dtype=int)
    d=squareform(pdist(native))
    dhat=squareform(pdist(predicted))
    separation=np.abs(pos[:,None]-pos[None,:])
    mask=(d<15.0)&(d>0.0)&(separation>1)
    counts=mask.sum(axis=1)
    valid=counts>0
    if not valid.any():
        raise ValueError('No valid reference-distance neighbors for lDDT')
    err=np.abs(d-dhat)
    local=np.zeros(len(native),dtype=np.float64)
    for t in (0.5,1.0,2.0,4.0):
        successes=((err<t)&mask).sum(axis=1)
        local[valid]+=successes[valid]/counts[valid]/4.0
    return float(local[valid].mean()),int(valid.sum())


def resolve(path, base):
    p=Path(str(path))
    if p.is_file():
        return p.resolve()
    if p.is_absolute():
        # An absolute manifest path can become stale after moving the release.
        # Resolve by an explicitly supported canonical experimental PDB location.
        alt=base/'cameo_data'/'experiment_structures'/p.name
        if alt.is_file():
            return alt.resolve()
        return p
    for candidate in (base/p,base.parent/p):
        if candidate.is_file():
            return candidate.resolve()
    return base/p


def pred_path(base,model,target,source_row=None):
    if model=='AlphaFold3':
        if source_row is None:
            raise ValueError('Missing AF3 evaluation row with prediction_path')
        return resolve(source_row['prediction_path'],base)
    if model=='Chai-1':
        path=base/'chai1'/'outputs'/target/'pred.model_idx_0.cif'
        if path.is_file(): return path
        if source_row is not None:
            return resolve(source_row['prediction_path'],base)
        return path
    if model=='ESMFold':
        return base/'esmfold'/'predictions'/f'{target}.pdb'
    if model=='Boltz-2':
        return base/'boltz2'/'outputs'/f'boltz_results_{target}'/'predictions'/target/f'{target}_model_0.cif'
    raise ValueError(model)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base',type=Path,default=Path('structure_prediction'))
    ap.add_argument('--reference',type=Path,default=None,help='Four-model metric CSV, for comparison only')
    ap.add_argument('--out',type=Path,default=Path('structure_metric_audit'))
    ap.add_argument('--mode',choices=('historical','common_mapping'),default='historical',
                    help='historical reproduces per-model input correspondences; common_mapping tests one mapping for all')
    ap.add_argument('--limit',type=int,default=0,help='Optional smoke-test target count')
    args=ap.parse_args()
    base=args.base.resolve()
    reference=args.reference or base/'evaluation_results'/'four_model_paired_complete.csv'
    reference=reference.resolve()
    scores=pd.read_csv(reference)
    targets=sorted(scores.target_id.unique())
    if args.limit>0: targets=targets[:args.limit]
    if scores.duplicated(['target_id','model']).any():
        raise ValueError('Duplicate target/model scores')
    manifest=pd.read_csv(base/'benchmark_manifest.csv').set_index('target_id')
    mapping=pd.read_csv(base/'esmfold'/'residue_alignment_mapping.csv',keep_default_na=False)
    af3=pd.read_csv(base/'evaluation_results'/'af3_accuracy_with_tm.csv').set_index('target_id')
    chai=pd.read_csv(base/'evaluation_results'/'chai1_accuracy.csv').set_index('target_id')
    out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
    records=[]
    for target in targets:
        try:
            native=read_structure(resolve(manifest.loc[target,'experimental_pdb'],base),'native')
            target_mapping=mapping.loc[mapping.target_id==target]
            if target_mapping.empty: raise ValueError('No reference mapping')
        except Exception as e:
            for model in MODELS:
                records.append({'target_id':target,'model':model,'status':'failed','error':f'native/mapping: {e}'})
            continue
        for model in MODELS:
            try:
                raw_row=af3.loc[target] if model=='AlphaFold3' else chai.loc[target] if model=='Chai-1' else None
                path=pred_path(base,model,target,raw_row)
                pred=read_structure(path,'prediction')
                pred_res=ca_residues(pred)
                if not pred_res: raise ValueError('No predicted C-alpha atoms')
                if args.mode=='historical' and model in ('AlphaFold3','Chai-1'):
                    native_chain=native[str(raw_row['native_chain'])]
                    native_res=ca_residues(native_chain)
                    pairs=sequence_pairs(native_res,pred_res)
                    # Derive FASTA positions for lDDT sequence separation from the
                    # reference mapping (not from CA-only row number).
                    key_to_pos={
                        (str(r.experimental_chain),int(r.experimental_residue_number),
                         str(r.experimental_insertion_code).strip() or ' '):int(r.fasta_position)
                        for r in target_mapping.itertuples(index=False)
                    }
                    positions=[]
                    for n,p,j in pairs:
                        key=(str(native_chain.id),int(n.id[1]),str(n.id[2]).strip() or ' ')
                        positions.append(key_to_pos.get(key,-1))
                    if any(p<0 for p in positions):
                        raise ValueError('AF3/Chai aligned residue absent from FASTA reference mapping')
                else:
                    pairs=mapping_pairs(native,pred_res,target_mapping)
                    positions=[pos for _,_,pos in pairs]
                if len(pairs)<10:raise ValueError(f'Too few matched residues: {len(pairs)}')
                if len(set(positions)) !=len(positions): raise ValueError('Duplicate mapped sequence positions')
                native_xyz=np.asarray([n['CA'].coord for n,p,j in pairs],dtype=np.float64)
                pred_xyz=np.asarray([p['CA'].coord for n,p,j in pairs],dtype=np.float64)
                sequence=''.join(as_aa(n) for n,p,j in pairs)
                rmsd=kabsch_rmsd(native_xyz,pred_xyz)
                lddt,n_valid=lddt_per_residue(native_xyz,pred_xyz,positions)
                tm=tm_align(native_xyz,pred_xyz,sequence,sequence)
                records.append({'target_id':target,'model':model,'status':'evaluated','error':'',
                                'matched_ca_residues':len(pairs),'lddt_valid_residues':n_valid,
                                'rmsd':rmsd,'tm_score':float(tm.tm_norm_chain1),'lddt_ca':lddt,
                                'predicted_path':str(path)})
            except Exception as e:
                records.append({'target_id':target,'model':model,'status':'failed','error':str(e)})
    actual=pd.DataFrame(records)
    actual.to_csv(out/'recomputed_structure_metrics.csv',index=False)
    new=actual.loc[actual.status=='evaluated',
                   ['target_id','model','matched_ca_residues','rmsd','tm_score','lddt_ca']]
    old=scores[scores.target_id.isin(targets)][['target_id','model','rmsd','tm_score','lddt_ca']]
    comparison=old.merge(new,on=['target_id','model'],suffixes=('_reported','_recomputed'),how='left',validate='one_to_one')
    for metric in ('rmsd','tm_score','lddt_ca'):
        comparison[f'abs_error_{metric}']=(comparison[f'{metric}_reported']-comparison[f'{metric}_recomputed']).abs()
    comparison.to_csv(out/'structure_metric_comparison.csv',index=False)
    print('Metric mode:',args.mode)
    print('Requested target-model pairs:',len(targets)*len(MODELS))
    print('Recomputed:',len(new),'Failed:',int((actual.status=='failed').sum()))
    print('By model:')
    print(actual.groupby(['model','status']).size().to_string())
    print('Maximum absolute differences:')
    print(comparison[[f'abs_error_{x}' for x in ('rmsd','tm_score','lddt_ca')]].max().to_string())
    print('Rows with >1e-4 TM/lDDT or >1e-3 Angstrom RMSD:',int((
        (comparison.abs_error_rmsd>1e-3)|
        (comparison.abs_error_tm_score>1e-4)|
        (comparison.abs_error_lddt_ca>1e-4)).sum()))
    print('Saved:',out)
    if (actual.status=='failed').any():
        print('\nFirst failures:')
        print(actual.loc[actual.status=='failed',['target_id','model','error']].head(12).to_string(index=False))

if __name__=='__main__':
    main()
