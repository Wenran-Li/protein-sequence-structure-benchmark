# Reproducible CAMEO structure prediction metrics

This release contains coordinate files for 124 experimental reference chains
and four predictions per target (496 pairs), together with provenance and
metric-computation scripts. It reproduces *historical* target-level metrics.

Tested: Python 3.9.16 and versions in requirements.txt.

From this archive root, run:

    python scripts/evaluate_structure_prediction.py \
      --base structure_prediction \
      --reference structure_prediction/evaluation_results/four_model_paired_complete.csv \
      --out results/historical --mode historical

For a FASTA-position-index sensitivity analysis (not identical to the
original lDDT indexing for AF3 and Chai-1), run:

    python scripts/evaluate_structure_prediction_fasta_index.py \
      --base structure_prediction \
      --reference structure_prediction/evaluation_results/four_model_paired_complete.csv \
      --out results/fasta_index --mode historical

Residue correspondence: AF3/Chai-1 use global sequence alignment, retaining
only identical amino-acid positions with both C-alpha atoms. ESMFold/Boltz-2
use the released FASTA-to-native residue mapping, with available C-alpha
positions. Historical lDDT excludes sequence neighbors according to extracted
native C-alpha residue-list indices for AF3/Chai-1 and mapped FASTA positions
for ESMFold/Boltz-2. The reference distance cutoff is 15 Angstrom; lDDT uses
0.5, 1, 2, and 4 Angstrom error thresholds and per-residue averaging.
TM-score is computed on matched arrays and normalized by matched length.
RMSD is C-alpha Kabsch least-squares after rigid-body superposition.
File SHA-256 checksums are included in file_manifest.csv.
